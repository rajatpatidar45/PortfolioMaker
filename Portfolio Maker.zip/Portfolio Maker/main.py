from flask import Flask,render_template,request,session
import uuid,os
app=Flask(__name__)
app.secret_key = "rootkey"

@app.route('/')
def home():
    return render_template("home.html")

@app.route('/design')
def design():
    return render_template("design.html")

@app.route('/form/<string:design>', methods= ["GET","POST"]) 
def form(design):
    session["design_session"]=design
    return render_template("form.html")

@app.route("/upload", methods=["GET","POST"])
def upload():
    design_upload= session.get("design_session")
    if design_upload == "portfolio":
        design_name = "portfolio.html"
    elif design_upload == "portfolio-2":
        design_name = "portfolio-2.html"
    if request.method == "POST":
        name= request.form.get("name")
        email=request.form.get("email")
        address=request.form.get("address")
        about=request.form.get("about")
        skill1=request.form.get("skill1")
        skill2=request.form.get("skill2")
        skill3=request.form.get("skill3")
        skill4=request.form.get("skill4")
        skill5=request.form.get("skill5")
        about2=request.form.get("about2")
        
        key= uuid.uuid1()
        # image uploading method
        image=request.files["img"]
        image.save(f"static/uploadimg/{image.filename}")
        img_new_name= f"{key}{image.filename}"
        os.rename(f"static/uploadimg/{image.filename}",f"static/uploadimg/{img_new_name}")
        return render_template(design_name,name=name,email=email,image=img_new_name,address=address,about=about,skill1=skill1,skill2=skill2,skill3=skill3,skill4=skill4,skill5=skill5,about2=about2)
  
if __name__ == "__main__":
    app.run(debug=True)
    